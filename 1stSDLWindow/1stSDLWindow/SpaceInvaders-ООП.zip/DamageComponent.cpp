
#include "DamageComponent.h"

DamageComponent::DamageComponent(int amount) : damageAmount(amount) {
}

void DamageComponent::init() {
    // Nothing to initialize
}

void DamageComponent::update() {
    // Nothing to update
}



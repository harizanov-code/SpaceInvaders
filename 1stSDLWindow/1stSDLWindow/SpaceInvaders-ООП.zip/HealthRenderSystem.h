#pragma once

#include "ECS.h"


class HealthRenderSystem {
public:
    static void Draw(Manager& manager);
};
